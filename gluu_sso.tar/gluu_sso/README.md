<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
    <link href="files/css/oxd_openid_style.css" rel="stylesheet">
</head>
<body>
<div id="dokuwiki__site">

    <div id="dokuwiki__top" class="dokuwiki site mode_show  ">
        <div class="">
            <div class="pad group">
                <div class="page group">
                   <img src="https://github.com/GluuFederation/gluu-sso-drupal-module/blob/master/doc-image/1.png">
                   <img src="https://github.com/GluuFederation/gluu-sso-drupal-module/blob/master/doc-image/2.png">
                   <img src="https://github.com/GluuFederation/gluu-sso-drupal-module/blob/master/doc-image/3.png">
                   <img src="https://github.com/GluuFederation/gluu-sso-drupal-module/blob/master/doc-image/4.png">
                   <img src="https://github.com/GluuFederation/gluu-sso-drupal-module/blob/master/doc-image/5.png">
                   <img src="https://github.com/GluuFederation/gluu-sso-drupal-module/blob/master/doc-image/6.png">
                   <img src="https://github.com/GluuFederation/gluu-sso-drupal-module/blob/master/doc-image/7.png">
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
