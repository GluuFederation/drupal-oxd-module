/**
 * Created by Vlad on 11/27/2015.
 */

jQuery.noConflict();
jQuery(document).ready(function(){
   jQuery('#gluu-sso-config-form').attr('name','form-apps')
});



