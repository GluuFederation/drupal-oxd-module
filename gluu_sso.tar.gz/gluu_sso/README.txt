CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Requirements
 * Installation
 * Configuration

INTRODUCTION
------------
Login to any Drupal site using credentials stored in Active Directory, Opensso
and other sso servers, especially when the AD or sso does not have a public IP
address. In other words, this module is best utilized If the sso Server is not
directly accessible from your Drupal site. There are two parts to this module
- One part sits on the Drupal site and the other sits on your DMZ. Additional
benefit is that there is no need to have the PHP sso extension enabled, hence
better usability.

REQUIREMENTS
------------
No Special Requirements

INSTALLATION
------------
Install as you would normally install a contributed Drupal module. See:
https://drupal.org/documentation/install/modules-themes/modules-7
for further information.

CONFIGURATION
-------------
 * Configure user permissions in Administration » People » miniOrange sso
 Module Configuration:


   - Setup Customer account with miniOrange


     Create/Login with miniOrange by entering email address, phone number and
     password.


   - Contact sso Server


     Enter sso Server URL(sso://<sso_server_url>:<port>) and try to contact
     it using the module.


   - Configure User Mapping and Bind


     This configuration determines the sso attributes which are bound to the
     user. It determines where the users are located in sso and what attributes
     are used as the username. The option to spcify usage of an external sso
     Gateway is also provided in this screen, along with the option to enable
     login via sso.

   - Test Authentication

     This page is used to mimic authentication for sso Users.
